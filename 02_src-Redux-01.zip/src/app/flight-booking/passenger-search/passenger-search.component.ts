
import { Component } from '@angular/core';
@Component({
  selector: 'passenger-search',
  template: `
    <h1>Passenger Search</h1>
  `
})
export class PassengerSearchComponent {
}
