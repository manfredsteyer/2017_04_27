import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'test',
    template: '<p>Unused Test Component!</p>'
})
export class TestComponent implements OnInit {
    constructor() { }


    ngOnInit() { }
}