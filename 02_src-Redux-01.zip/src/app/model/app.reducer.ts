import { flightReducer } from './flights/flights.reducers';

export const appReducerMap = {
  flights: flightReducer
  // otherThings: otherThingsReducer
}
